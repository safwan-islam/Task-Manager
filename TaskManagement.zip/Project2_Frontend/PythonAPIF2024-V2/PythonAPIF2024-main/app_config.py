CONST_MONGO_URL = "mongodb+srv://safwan514123:c6Ij272p1k5bKkdn@cluster0.ith06.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
CONST_DATABASE = "LS3FALL2024"
CONST_USER_COLLECTION = "Users"
CONST_TASK_COLLECTION = "tasks"

JWT_EXPIRATION = 86400*30
TOKEN_SECRET = "ls3fall"
